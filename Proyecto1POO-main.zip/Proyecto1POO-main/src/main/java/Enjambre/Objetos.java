/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Enjambre;

/**
 *
 * @author Ana
 */
public abstract class Objetos {
    public abstract int getPosX();

    public abstract void setPosX(int posX);

    public abstract int getPosY();

    public abstract void setPosY(int posY);

    public abstract boolean isActivo();

    public abstract void setActivo(boolean activo);
}

